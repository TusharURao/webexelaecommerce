export type EmailTemplate = 'PRODUCT_KEY_DELIVERY' | 'PAYMENT_CONFIRMATION';

export interface PaymentDetails {
  transactionId: string;
  amount: number;
  currency: string;
  status: 'success' | 'failed';
  timestamp: string;
}

export interface ProductKey {
  key: string;
  productId: string;
  activationInstructions: string;
}