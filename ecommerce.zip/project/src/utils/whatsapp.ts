export const sendWhatsAppMessage = async (phone: string, message: string) => {
  try {
    // Remove any non-numeric characters and ensure it starts with country code
    const formattedPhone = phone.replace(/\D/g, '');
    const phoneWithCountryCode = formattedPhone.startsWith('91') 
      ? formattedPhone 
      : `91${formattedPhone}`;

    // Create WhatsApp link
    const whatsappLink = `https://wa.me/${phoneWithCountryCode}?text=${encodeURIComponent(message)}`;
    
    // Open WhatsApp in a new tab
    window.open(whatsappLink, '_blank');
    
    return true;
  } catch (error) {
    console.error('WhatsApp message sending failed:', error);
    throw error;
  }
};