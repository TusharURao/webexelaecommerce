import { EmailTemplate } from '../types';

export const sendEmail = async (to: string, template: EmailTemplate, data: any) => {
  try {
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to,
        template,
        data,
      }),
    });

    if (!response.ok) throw new Error('Failed to send email');
    
    return await response.json();
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
};