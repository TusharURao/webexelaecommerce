import React, { useState, useEffect } from 'react';
import { Star, ShoppingCart, ChevronRight, ChevronLeft } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import PaymentProcessor from '../components/PaymentProcessor';
import { useCart } from '../context/CartContext';
import { supabase } from '../lib/supabase';

interface LicenseType {
  id: string;
  name: string;
  description: string;
}

interface ProductDetails {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice: number;
  discount: number;
  features: string[];
}

const ProductDetail = () => {
  const { productId } = useParams();
  const [selectedLicense, setSelectedLicense] = useState<string>('online');
  const [quantity, setQuantity] = useState<number>(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [productDetails, setProductDetails] = useState<ProductDetails | null>(null);
  const { addItem } = useCart();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*')
          .eq('id', productId)
          .single();

        if (error) throw error;

        if (data) {
          setProductDetails({
            id: data.id,
            title: data.title,
            description: data.description || '',
            price: data.price,
            originalPrice: data.original_price,
            discount: data.discount || 0,
            features: [
              'Lifetime License',
              'Official Microsoft Product',
              'Digital Download',
              'Instant Email Delivery',
              '24/7 Support',
              'Money Back Guarantee'
            ]
          });
        }
      } catch (err) {
        console.error('Error fetching product:', err);
        setError('Failed to load product details');
      } finally {
        setLoading(false);
      }
    };

    if (productId) {
      fetchProduct();
    }
  }, [productId]);

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  const handleAddToCart = () => {
    if (!productDetails) return;
    
    addItem({
      id: productId || '',
      title: productDetails.title,
      price: productDetails.price,
      quantity: quantity,
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1200'
    });
  };

  const handlePaymentSuccess = async (transactionId: string) => {
    try {
      const response = await fetch('/api/deliver-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transactionId,
          productId,
        }),
      });

      if (!response.ok) throw new Error('Failed to process delivery');

      const { message } = await response.json();
      alert('Payment successful! Check your email for the product key.');
    } catch (error) {
      console.error('Delivery failed:', error);
      alert('Payment successful but key delivery failed. Our team will contact you shortly.');
    }
  };

  const licenseTypes: LicenseType[] = [
    {
      id: 'online',
      name: 'Online Activation Key',
      description: 'Standard online activation process through Microsoft servers.',
    },
    {
      id: 'phone',
      name: 'Telephonic Activation Key',
      description: 'Activate your license easily through our telephonic process. It\'s a quick 2-minute procedure, and activation support is readily available.',
    },
  ];

  if (loading) {
    return (
      <div className="pt-20 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading product details...</p>
        </div>
      </div>
    );
  }

  if (error || !productDetails) {
    return (
      <div className="pt-20 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error || 'Product not found'}</p>
          <Link to="/" className="text-black hover:underline">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center space-x-2 text-sm">
            <Link to="/" className="text-gray-600 hover:text-black">Home</Link>
            <ChevronRight className="w-4 h-4 text-gray-400" />
            <Link to="/shop" className="text-gray-600 hover:text-black">Shop</Link>
            <ChevronRight className="w-4 h-4 text-gray-400" />
            <span className="text-gray-900">{productDetails.title}</span>
          </div>
        </div>
      </div>

      {/* Product Section */}
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <img 
              src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1200"
              alt={productDetails.title}
              className="w-full rounded-lg shadow-lg"
            />
          </div>

          {/* Product Info */}
          <div>
            <h1 className="text-3xl font-bold mb-4">{productDetails.title}</h1>
            
            {/* Rating */}
            <div className="flex items-center mb-6">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
                <span className="ml-2 text-gray-600">(1451 reviews)</span>
              </div>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-center space-x-4">
                <span className="text-3xl font-bold">₹{productDetails.price}</span>
                <span className="text-xl text-gray-500 line-through">₹{productDetails.originalPrice}</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded">{productDetails.discount}% Off</span>
              </div>
            </div>

            {/* Key Features */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Key Features</h3>
              <ul className="grid grid-cols-2 gap-2">
                {productDetails.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-600">
                    <ChevronRight className="w-4 h-4 mr-2 text-green-500" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* License Type Selection */}
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Type of License</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {licenseTypes.map((type) => (
                  <div
                    key={type.id}
                    className={`border p-4 rounded-lg cursor-pointer ${
                      selectedLicense === type.id ? 'border-black' : 'border-gray-200'
                    }`}
                    onClick={() => setSelectedLicense(type.id)}
                  >
                    <div className="flex items-center mb-2">
                      <div className={`w-4 h-4 rounded-full border-2 ${
                        selectedLicense === type.id ? 'border-black bg-black' : 'border-gray-300'
                      }`} />
                      <span className="ml-2 font-medium">{type.name}</span>
                    </div>
                    <p className="text-sm text-gray-600">{type.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Quantity and Buttons */}
            <div className="flex items-center space-x-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="w-20 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-black"
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-gray-800 text-white py-3 rounded-lg hover:bg-gray-700 transition-colors flex items-center justify-center"
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Add to Cart
              </button>
              
              <PaymentProcessor
                amount={productDetails.price * quantity}
                productId={productId || ''}
                productTitle={productDetails.title}
                onSuccess={handlePaymentSuccess}
              />
            </div>
          </div>
        </div>

        {/* Product Description */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Product Description</h2>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="prose max-w-none">
              {productDetails.description.split('\n\n').map((paragraph, index) => {
                if (paragraph.startsWith('•')) {
                  const items = paragraph.split('\n');
                  return (
                    <ul key={index} className="list-disc pl-4 mb-4">
                      {items.map((item, i) => (
                        <li key={i}>{item.replace('•', '').trim()}</li>
                      ))}
                    </ul>
                  );
                }
                return <p key={index} className="mb-4">{paragraph}</p>;
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;