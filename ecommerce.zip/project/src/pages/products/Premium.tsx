import React from 'react';
import ProductList from '../../components/ProductList';

const premiumProducts = [
  {
    id: '1',
    title: 'LinkedIn Premium Career (1 Year)',
    rating: 4.7,
    reviews: 523,
    price: {
      current: 1499,
      original: 14999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&q=80&w=1200',
    description: 'Access premium job search features and career development tools.',
  },
  {
    id: '2',
    title: 'Canva Pro Annual Subscription',
    rating: 4.9,
    reviews: 892,
    price: {
      current: 399,
      original: 3999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=1200',
    description: 'Professional design tools and premium content access.',
  },
  {
    id: '3',
    title: 'ChatGPT Plus Subscription',
    rating: 4.8,
    reviews: 671,
    price: {
      current: 299,
      original: 2999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1200',
    description: 'Priority access to GPT-4 and new features.',
  },
  {
    id: '4',
    title: 'Amazon Prime Annual Membership',
    rating: 4.9,
    reviews: 1234,
    price: {
      current: 599,
      original: 5999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&q=80&w=1200',
    description: 'Unlimited free delivery, Prime Video, and more.',
  },
  {
    id: '5',
    title: 'YouTube Premium Family Plan',
    rating: 4.7,
    reviews: 892,
    price: {
      current: 399,
      original: 3999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?auto=format&fit=crop&q=80&w=1200',
    description: 'Ad-free YouTube experience for up to 6 family members.',
  }
];

const description = `Access premium subscriptions and services at discounted prices. From professional networking to design tools and streaming services, we offer authentic premium accounts with guaranteed access.`;

const PremiumPage = () => {
  return (
    <ProductList 
      category="Premium Services"
      description={description}
      products={premiumProducts}
    />
  );
};

export default PremiumPage;