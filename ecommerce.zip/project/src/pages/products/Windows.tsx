import React from 'react';
import ProductList from '../../components/ProductList';

const windowsProducts = [
  {
    id: '1',
    title: 'Windows 11 Pro Retail License Key',
    rating: 4.9,
    reviews: 892,
    price: {
      current: 399,
      original: 3999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1624571409108-e9d6c6f2f567?auto=format&fit=crop&q=80&w=1200',
    description: 'Genuine Windows 11 Pro retail license key with lifetime validity.',
  },
  {
    id: '2',
    title: 'Windows 10 Pro LTSC',
    rating: 4.8,
    reviews: 567,
    price: {
      current: 349,
      original: 2999,
    },
    discount: 88,
    image: 'https://images.unsplash.com/photo-1551645120-d70bfe84c826?auto=format&fit=crop&q=80&w=1200',
    description: 'Windows 10 Pro LTSC edition with long-term support and updates.',
  },
  {
    id: '3',
    title: 'Windows 11 Home Retail Key',
    rating: 4.7,
    reviews: 423,
    price: {
      current: 299,
      original: 2499,
    },
    discount: 88,
    image: 'https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&q=80&w=1200',
    description: 'Perfect for home users with all essential features.',
  },
  {
    id: '4',
    title: 'Windows 10 Enterprise E3',
    rating: 4.9,
    reviews: 289,
    price: {
      current: 599,
      original: 5999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1593642532744-d377ab507dc8?auto=format&fit=crop&q=80&w=1200',
    description: 'Advanced security and management features for enterprises.',
  },
  {
    id: '5',
    title: 'Windows Server 2022 Standard',
    rating: 4.8,
    reviews: 156,
    price: {
      current: 899,
      original: 8999,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=1200',
    description: 'Server operating system for business infrastructure.',
  }
];

const description = `Get genuine Windows operating system licenses at the best prices. Whether you need Windows 10 or Windows 11, we offer authentic retail keys with lifetime validity and instant delivery. Our Windows licenses come with full feature access and official Microsoft support.`;

const WindowsPage = () => {
  return (
    <ProductList 
      category="Windows"
      description={description}
      products={windowsProducts}
    />
  );
};

export default WindowsPage;