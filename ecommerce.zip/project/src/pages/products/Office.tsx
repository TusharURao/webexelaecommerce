import React from 'react';
import ProductList from '../../components/ProductList';

const officeProducts = [
  {
    id: "550e8400-e29b-41d4-a716-446655440000", // Using UUID format
    title: 'Office 2021 Professional Plus Retail License Key',
    rating: 4.8,
    reviews: 1451,
    price: {
      current: 449,
      original: 4999,
    },
    discount: 91,
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1200',
    description: 'Lifetime valid retail license key with instant email delivery. Includes Word, Excel, PowerPoint, Outlook, and more.',
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440001",
    title: 'Office 365 Professional Plus – 5 Devices PC/MAC',
    rating: 4.7,
    reviews: 339,
    price: {
      current: 297,
      original: 2970,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=1200',
    description: 'Professional Plus subscription for 5 devices, PC/MAC compatible with all latest features.',
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440002",
    title: 'Office 2021 Home & Business for Mac',
    rating: 4.9,
    reviews: 892,
    price: {
      current: 399,
      original: 3499,
    },
    discount: 89,
    image: 'https://images.unsplash.com/photo-1537498425277-c283d32ef9db?auto=format&fit=crop&q=80&w=1200',
    description: 'Perfect for Mac users, includes Word, Excel, PowerPoint, and Outlook.',
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440003",
    title: 'Office 2021 Home & Student',
    rating: 4.6,
    reviews: 567,
    price: {
      current: 249,
      original: 2499,
    },
    discount: 90,
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&q=80&w=1200',
    description: 'Essential Office apps for students and home users.',
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440004",
    title: 'Microsoft 365 Family (6 Users)',
    rating: 4.8,
    reviews: 723,
    price: {
      current: 499,
      original: 5299,
    },
    discount: 91,
    image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=1200',
    description: 'Complete Office suite for up to 6 users with 1TB OneDrive storage each.',
  }
];

const description = `Microsoft Office is the essential software for retail users, small businesses, and families or corporations who need the most popular Microsoft Office apps like Word, Excel, PowerPoint, Outlook, OneNote, Publisher, Access, Skype, MS Teams, Visio Professional, and Project Professional. Microsoft office tools keep you organized and productive whether for business or home use.`;

const OfficePage = () => {
  return (
    <ProductList 
      category="Microsoft Office"
      description={description}
      products={officeProducts}
    />
  );
};

export default OfficePage;