import React from 'react';
import { Shield, Clock, CreditCard, ChevronRight } from 'lucide-react';

const Home = () => {
  const categories = [
    {
      title: "Microsoft Office",
      description: "Professional software suite for productivity",
      image: "https://images.unsplash.com/photo-1633419461186-7d40a38105ec?auto=format&fit=crop&q=80&w=800",
      link: "/category/microsoft-365"
    },
    {
      title: "Windows",
      description: "Genuine Windows OS licenses",
      image: "https://images.unsplash.com/photo-1624571409108-e9d6c6f2f567?auto=format&fit=crop&q=80&w=800",
      link: "/category/windows"
    },
    {
      title: "Premium Services",
      description: "Premium subscriptions and services",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800",
      link: "/category/premium"
    }
  ];

  const features = [
    {
      icon: <Shield className="w-12 h-12 text-black" />,
      title: "Secure & Authentic",
      description: "100% genuine product keys"
    },
    {
      icon: <Clock className="w-12 h-12 text-black" />,
      title: "Instant Delivery",
      description: "Immediate access after purchase"
    },
    {
      icon: <CreditCard className="w-12 h-12 text-black" />,
      title: "Secure Payment",
      description: "Protected transaction process"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] bg-black text-white flex items-center">
        <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=2000" 
          alt="Hero"
          className="absolute inset-0 w-full h-full object-cover opacity-50"
        />
        <div className="container mx-auto px-6 relative z-20">
          <h1 className="text-5xl font-bold mb-6 animate-fade-in">
            Premium Software Keys
            <br />
            <span className="text-gray-300">Lifetime Access</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-xl">
            Authentic licenses for professional software and premium subscriptions at competitive prices.
          </p>
          <a 
            href="/category/microsoft-365"
            className="inline-flex items-center bg-white text-black px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-300 group"
          >
            Browse Products
            <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-4">
                {feature.icon}
                <div>
                  <h3 className="font-semibold text-xl">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Popular Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <a 
                key={index}
                href={category.link}
                className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="aspect-w-16 aspect-h-9">
                  <img 
                    src={category.image}
                    alt={category.title}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
                  <p className="text-gray-200">{category.description}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-black text-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">10K+</div>
              <p className="text-gray-400">Happy Customers</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">24/7</div>
              <p className="text-gray-400">Customer Support</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">100%</div>
              <p className="text-gray-400">Genuine Products</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">30-Day</div>
              <p className="text-gray-400">Money Back Guarantee</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;