import React from 'react';
import { Mail, Phone, MessageCircle, Clock } from 'lucide-react';

const Support = () => {
  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-black text-white py-20">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold mb-6 text-center">How Can We Help?</h1>
          <p className="text-xl text-gray-300 text-center max-w-2xl mx-auto">
            Our support team is here to assist you with any questions or concerns about our products and services.
          </p>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Mail className="w-12 h-12 mx-auto mb-4 text-gray-800" />
              <h3 className="text-xl font-semibold mb-2">Email Support</h3>
              <p className="text-gray-600 mb-4">Get in touch via email</p>
              <a href="mailto:support@softkeys.com" className="text-blue-600 hover:underline">
                support@softkeys.com
              </a>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Phone className="w-12 h-12 mx-auto mb-4 text-gray-800" />
              <h3 className="text-xl font-semibold mb-2">Phone Support</h3>
              <p className="text-gray-600 mb-4">Call us directly</p>
              <a href="tel:+15551234567" className="text-blue-600 hover:underline">
                +1 (555) 123-4567
              </a>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 text-gray-800" />
              <h3 className="text-xl font-semibold mb-2">Live Chat</h3>
              <p className="text-gray-600 mb-4">Chat with our team</p>
              <button className="text-blue-600 hover:underline">
                Start Chat
              </button>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Clock className="w-12 h-12 mx-auto mb-4 text-gray-800" />
              <h3 className="text-xl font-semibold mb-2">Support Hours</h3>
              <p className="text-gray-600">Mon - Fri: 9AM - 6PM</p>
              <p className="text-gray-600">Sat - Sun: 10AM - 4PM</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">How do I activate my product key?</h3>
              <p className="text-gray-600">
                After purchase, you'll receive your product key via email. Follow the activation instructions provided in the email to activate your software.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">What if my key doesn't work?</h3>
              <p className="text-gray-600">
                If you experience any issues with your product key, please contact our support team immediately. We'll help resolve the issue or provide a replacement key.
              </p>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Do you offer refunds?</h3>
              <p className="text-gray-600">
                Yes, we offer a 30-day money-back guarantee if you're not satisfied with your purchase. Contact our support team to initiate the refund process.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Support;