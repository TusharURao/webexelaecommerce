export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string | null
          phone: string | null
          address: string | null
          city: string | null
          state: string | null
          pincode: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          name?: string | null
          phone?: string | null
          address?: string | null
          city?: string | null
          state?: string | null
          pincode?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string | null
          phone?: string | null
          address?: string | null
          city?: string | null
          state?: string | null
          pincode?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: string
          title: string
          description: string | null
          price: number
          original_price: number
          discount: number | null
          image_url: string | null
          category: string
          rating: number | null
          reviews_count: number | null
          stock: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          price: number
          original_price: number
          discount?: number | null
          image_url?: string | null
          category: string
          rating?: number | null
          reviews_count?: number | null
          stock?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          price?: number
          original_price?: number
          discount?: number | null
          image_url?: string | null
          category?: string
          rating?: number | null
          reviews_count?: number | null
          stock?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          user_id: string
          status: string
          total_amount: number
          payment_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          status: string
          total_amount: number
          payment_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          status?: string
          total_amount?: number
          payment_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      order_items: {
        Row: {
          id: string
          order_id: string
          product_id: string
          quantity: number
          price: number
          created_at: string
        }
        Insert: {
          id?: string
          order_id: string
          product_id: string
          quantity: number
          price: number
          created_at?: string
        }
        Update: {
          id?: string
          order_id?: string
          product_id?: string
          quantity?: number
          price?: number
          created_at?: string
        }
      }
      product_keys: {
        Row: {
          id: string
          product_id: string
          key_value: string
          is_used: boolean
          order_id: string | null
          created_at: string
          used_at: string | null
        }
        Insert: {
          id?: string
          product_id: string
          key_value: string
          is_used?: boolean
          order_id?: string | null
          created_at?: string
          used_at?: string | null
        }
        Update: {
          id?: string
          product_id?: string
          key_value?: string
          is_used?: boolean
          order_id?: string | null
          created_at?: string
          used_at?: string | null
        }
      }
    }
  }
}