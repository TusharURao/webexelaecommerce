import crypto from 'crypto';

export function verifyPayment(
  orderId: string,
  paymentId: string,
  signature: string
) {
  const text = orderId + "|" + paymentId;
  const generated_signature = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!)
    .update(text)
    .digest("hex");
    
  return generated_signature === signature;
}