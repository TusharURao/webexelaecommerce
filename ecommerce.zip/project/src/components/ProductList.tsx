import React, { useState } from 'react';
import { Grid, List } from 'lucide-react';
import ProductCard from './ProductCard';

interface Product {
  id: string;
  title: string;
  rating: number;
  reviews: number;
  price: {
    current: number;
    original: number;
  };
  discount: number;
  image: string;
  description?: string;
}

interface ProductListProps {
  category: string;
  description: string;
  products: Product[];
}

const ProductList: React.FC<ProductListProps> = ({ category, description, products }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('popularity');
  const [itemsPerPage, setItemsPerPage] = useState(12);

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      {/* Category Header */}
      <section className="bg-black text-white py-16">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold mb-6">Buy {category} Online</h1>
          <p className="text-gray-300 max-w-4xl">{description}</p>
        </div>
      </section>

      {/* Product Listing */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          {/* Filters and View Options */}
          <div className="flex flex-wrap items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-black text-white' : 'bg-gray-200'}`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-black text-white' : 'bg-gray-200'}`}
              >
                <List className="w-5 h-5" />
              </button>
              <select 
                value={itemsPerPage}
                onChange={(e) => setItemsPerPage(Number(e.target.value))}
                className="border rounded p-2"
              >
                <option value={12}>Show 12</option>
                <option value={24}>Show 24</option>
                <option value={36}>Show 36</option>
              </select>
            </div>

            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="border rounded p-2"
            >
              <option value="popularity">Sort by popularity</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Sort by rating</option>
            </select>
          </div>

          {/* Products Grid/List */}
          <div className={`grid ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
              : 'grid-cols-1 gap-4'
          }`}>
            {products.slice(0, itemsPerPage).map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>

          {/* Load More Button */}
          {products.length > itemsPerPage && (
            <div className="text-center mt-8">
              <button 
                onClick={() => setItemsPerPage(prev => prev + 12)}
                className="bg-black text-white px-6 py-2 rounded hover:bg-gray-800"
              >
                Load More Products
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default ProductList;