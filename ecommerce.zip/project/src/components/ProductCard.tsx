import React from 'react';
import { ShoppingCart, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  id: string;
  title: string;
  rating: number;
  reviews: number;
  price: {
    current: number;
    original: number;
  };
  discount: number;
  image: string;
  description?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  id, 
  title, 
  rating, 
  reviews, 
  price, 
  discount, 
  image, 
  description 
}) => {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation
    addItem({
      id,
      title,
      price: price.current,
      quantity: 1,
      image
    });
  };

  return (
    <Link to={`/product/${id}`} className="group">
      <div className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
        <div className="relative">
          <img 
            src={image} 
            alt={title}
            className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity duration-300 flex items-center justify-center">
            <div className="space-x-2 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
              <button 
                onClick={handleAddToCart}
                className="bg-white text-black px-4 py-2 rounded-lg hover:bg-gray-100 flex items-center"
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Add to Cart
              </button>
            </div>
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{title}</h3>
          <div className="flex items-center mb-2">
            <div className="flex items-center text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  className={`w-4 h-4 ${i < rating ? 'fill-current' : ''}`} 
                />
              ))}
            </div>
            <span className="text-gray-600 text-sm ml-2">({reviews})</span>
          </div>
          {description && (
            <p className="text-gray-600 mb-4">{description}</p>
          )}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-2xl font-bold">₹{price.current}</span>
              <span className="text-gray-500 line-through ml-2">₹{price.original}</span>
              <span className="text-green-600 ml-2">{discount}% Off</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;