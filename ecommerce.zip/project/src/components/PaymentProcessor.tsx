import React, { useState } from 'react';
import { CreditCard, Smartphone } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { sendWhatsAppMessage } from '../utils/whatsapp';
import PurchaseForm from './PurchaseForm';
import AuthModal from './AuthModal';

interface PaymentProcessorProps {
  amount: number;
  productId: string;
  productTitle: string;
  onSuccess: (transactionId: string) => void;
}

const PaymentProcessor: React.FC<PaymentProcessorProps> = ({ 
  amount, 
  productId, 
  productTitle,
  onSuccess 
}) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showPurchaseForm, setShowPurchaseForm] = useState(false);
  const [customerDetails, setCustomerDetails] = useState(null);
  const [error, setError] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handlePurchaseFormSubmit = async (formData: any) => {
    setLoading(true);
    setError(null);
    setCustomerDetails(formData);
    
    try {
      const message = `🛍️ *New Order from SoftKeys*\n\n*Product Details:*\nProduct: ${productTitle}\nPrice: ₹${amount}\nGST (18%): ₹${(amount * 0.18).toFixed(2)}\nTotal: ₹${(amount * 1.18).toFixed(2)}\n\n*Customer Details:*\nName: ${formData.name}\nEmail: ${formData.email}\n\nYour order has been received! Our team will process it shortly.\n\nNeed help? Contact us:\n📞 Support: +91 XXXXXXXXXX\n✉️ Email: support@softkeys.com\n\nThank you for choosing SoftKeys! 🙏`;

      await sendWhatsAppMessage(formData.phone, message);
      
      // Proceed with payment
      handlePayment();
    } catch (error) {
      console.error('Failed to process purchase:', error);
      setError('Failed to process purchase. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePayment = async () => {
    if (!customerDetails) {
      setError('Please fill in your details first');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const totalAmount = Math.round(amount * 1.18); // Including 18% GST
      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_key',
        amount: totalAmount * 100,
        currency: "INR",
        name: "SoftKeys",
        description: `Purchase ${productTitle}`,
        prefill: {
          name: customerDetails.name || "",
          email: customerDetails.email || "",
          contact: customerDetails.phone || ""
        },
        handler: async function (response: any) {
          try {
            onSuccess(response.razorpay_payment_id);
            // Send confirmation message after successful payment
            const successMessage = `🎉 *Payment Successful!*\n\nYour payment for ${productTitle} has been received.\nTransaction ID: ${response.razorpay_payment_id}\n\nYour product key will be sent shortly.\n\nThank you for shopping with SoftKeys! 🙏`;
            await sendWhatsAppMessage(customerDetails.phone, successMessage);
          } catch (error) {
            console.error('Failed to send success message:', error);
            // Don't throw error here as payment was successful
          }
        },
        modal: {
          ondismiss: function() {
            setLoading(false);
          }
        }
      };

      const razorpay = new (window as any).Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error('Payment initialization failed:', error);
      setError('Failed to initialize payment. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="text-center p-6 bg-gray-50 rounded-lg">
        <p className="mb-4">Please log in to continue with your purchase</p>
        <button
          onClick={() => setIsAuthModalOpen(true)}
          className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800"
        >
          Login to Continue
        </button>
        <AuthModal 
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          defaultTab="login"
        />
      </div>
    );
  }

  if (!showPurchaseForm) {
    return (
      <button
        onClick={() => setShowPurchaseForm(true)}
        className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors"
        disabled={loading}
      >
        Buy Now
      </button>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}
      
      <PurchaseForm
        product={{ id: productId, title: productTitle, price: { current: amount } }}
        onSubmit={handlePurchaseFormSubmit}
        initialData={{
          name: user?.user_metadata?.name || '',
          email: user?.email || '',
        }}
      />

      {loading && (
        <div className="text-center text-gray-600">
          Processing your request...
        </div>
      )}
    </div>
  );
};

export default PaymentProcessor;