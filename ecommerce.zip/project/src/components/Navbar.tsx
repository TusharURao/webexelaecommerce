import React, { useState } from 'react';
import { ShoppingCart, Menu, X, Search } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import SearchBar from './SearchBar';
import DropdownMenu from './DropdownMenu';
import UserMenu from './UserMenu';
import AuthModal from './AuthModal';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const location = useLocation();
  const { itemCount } = useCart();

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const microsoftProducts = [
    { title: 'Microsoft 365', href: '/category/microsoft-365' },
    { title: 'Windows', href: '/category/windows' },
    { title: 'Mac', href: '/category/mac' },
    { title: 'Copilot', href: '/category/copilot' },
    { title: 'Power Automate', href: '/category/power-automate' },
    { title: 'Fabric', href: '/category/fabric' },
  ];

  const premiumProducts = [
    { title: 'LinkedIn', href: '/category/linkedin' },
    { title: 'Canva Pro', href: '/category/canva-pro' },
    { title: 'Google One', href: '/category/google-one' },
    { title: 'ChatGPT 4', href: '/category/chatgpt' },
    { title: 'Amazon Prime', href: '/category/amazon-prime' },
    { title: 'YouTube', href: '/category/youtube' },
    { title: 'Coursera Premium', href: '/category/coursera' },
    { title: 'Proxplity AI', href: '/category/proxplity-ai' },
  ];

  const handleLogin = () => {
    setIsAuthModalOpen(true);
  };

  const handleLogout = () => {
    setUser(null);
    // Implement logout logic
  };

  const isHomePage = location.pathname === '/';
  const navbarBg = isScrolled || !isHomePage ? 'bg-white text-black shadow-lg' : 'bg-transparent text-white';

  return (
    <>
      <nav className={`fixed w-full z-50 transition-all duration-300 ${navbarBg}`}>
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-8">
              <Link to="/" className="text-2xl font-bold">SoftKeys</Link>
              <UserMenu 
                user={user}
                onLogin={handleLogin}
                onLogout={handleLogout}
              />
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <Link to="/" className="hover:text-gray-400 transition-colors">Home</Link>
              <DropdownMenu title="Microsoft" items={microsoftProducts} />
              <DropdownMenu title="Premium" items={premiumProducts} />
              <Link to="/support" className="hover:text-gray-400 transition-colors">Support</Link>
              
              <button 
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="hover:text-gray-400 transition-colors"
              >
                <Search className="w-6 h-6" />
              </button>
              
              <Link to="/cart" className="relative">
                <ShoppingCart className="w-6 h-6 cursor-pointer hover:text-gray-400 transition-colors" />
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-black text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Search Bar */}
          {isSearchOpen && (
            <div className="absolute top-20 left-0 w-full bg-white shadow-lg p-4">
              <SearchBar onClose={() => setIsSearchOpen(false)} />
            </div>
          )}

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white text-black">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <Link to="/" className="block px-3 py-2 rounded-md hover:bg-gray-100">Home</Link>
                <Link to="/category/microsoft-365" className="block px-3 py-2 rounded-md hover:bg-gray-100">Microsoft</Link>
                <Link to="/category/premium" className="block px-3 py-2 rounded-md hover:bg-gray-100">Premium</Link>
                <Link to="/support" className="block px-3 py-2 rounded-md hover:bg-gray-100">Support</Link>
                <Link to="/cart" className="block px-3 py-2 rounded-md hover:bg-gray-100">Cart</Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </>
  );
};

export default Navbar;