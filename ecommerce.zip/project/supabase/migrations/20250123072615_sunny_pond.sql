/*
  # Seed Initial Data

  1. Products
    - Add sample products for each category
    - Set initial prices and stock
*/

-- Seed products
INSERT INTO products (title, description, price, original_price, discount, image_url, category, rating, reviews_count, stock) VALUES
-- Microsoft Office Products
('Office 2021 Professional Plus', 'Lifetime valid retail license key with instant email delivery. Includes Word, Excel, PowerPoint, Outlook, and more.', 449, 4999, 91, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.8, 1451, 100),
('Office 365 Professional Plus', 'Professional Plus subscription for 5 devices, PC/MAC compatible with all latest features.', 297, 2970, 90, 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.7, 339, 100),
('Office 2021 Home & Business', 'Perfect for Mac users, includes Word, Excel, PowerPoint, and Outlook.', 399, 3499, 89, 'https://images.unsplash.com/photo-1537498425277-c283d32ef9db?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.9, 892, 100),

-- Windows Products
('Windows 11 Pro', 'Genuine Windows 11 Pro retail license key with lifetime validity.', 399, 3999, 90, 'https://images.unsplash.com/photo-1624571409108-e9d6c6f2f567?auto=format&fit=crop&q=80&w=1200', 'windows', 4.9, 892, 100),
('Windows 10 Pro LTSC', 'Windows 10 Pro LTSC edition with long-term support and updates.', 349, 2999, 88, 'https://images.unsplash.com/photo-1551645120-d70bfe84c826?auto=format&fit=crop&q=80&w=1200', 'windows', 4.8, 567, 100),
('Windows 11 Home', 'Perfect for home users with all essential features.', 299, 2499, 88, 'https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&q=80&w=1200', 'windows', 4.7, 423, 100),

-- Premium Products
('LinkedIn Premium Career', 'Access premium job search features and career development tools.', 1499, 14999, 90, 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&q=80&w=1200', 'premium', 4.7, 523, 100),
('Canva Pro Annual', 'Professional design tools and premium content access.', 399, 3999, 90, 'https://images.unsplash.com/photo-1611926653458-09294b3142bf?auto=format&fit=crop&q=80&w=1200', 'premium', 4.9, 892, 100),
('ChatGPT Plus', 'Priority access to GPT-4 and new features.', 299, 2999, 90, 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1200', 'premium', 4.8, 671, 100);

-- Add sample product keys (in a real environment, these would be securely generated and stored)
INSERT INTO product_keys (product_id, key_value, is_used)
SELECT 
  p.id,
  'SAMPLE-KEY-' || gen_random_uuid(),
  false
FROM products p
CROSS JOIN generate_series(1, 10);