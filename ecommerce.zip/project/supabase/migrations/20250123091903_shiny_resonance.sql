-- Clear existing data
TRUNCATE products CASCADE;

-- Seed products
INSERT INTO products (id, title, description, price, original_price, discount, image_url, category, rating, reviews_count, stock) VALUES
-- Microsoft Office Products
('550e8400-e29b-41d4-a716-446655440000', 'Office 2021 Professional Plus', 'Microsoft Office Professional 2021 is designed for businesses and professionals who need the full power of Office desktop programs. This latest version includes classic versions of the Office apps with some new features added to help maximize productivity.

Key Features:
• Word 2021 - Create and edit documents with advanced formatting tools
• Excel 2021 - Analyze and visualize data in new ways
• PowerPoint 2021 - Design professional presentations
• Outlook 2021 - Manage email, calendars, contacts, and tasks
• Access 2021 - Build custom database apps quickly
• Publisher 2021 - Create professional publications', 449, 4999, 91, 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.8, 1451, 100),

('550e8400-e29b-41d4-a716-446655440001', 'Office 365 Professional Plus – 5 Devices PC/MAC', 'Professional Plus subscription for 5 devices, PC/MAC compatible with all latest features.', 297, 2970, 90, 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.7, 339, 100),

('550e8400-e29b-41d4-a716-446655440002', 'Office 2021 Home & Business for Mac', 'Perfect for Mac users, includes Word, Excel, PowerPoint, and Outlook.', 399, 3499, 89, 'https://images.unsplash.com/photo-1537498425277-c283d32ef9db?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.9, 892, 100),

('550e8400-e29b-41d4-a716-446655440003', 'Office 2021 Home & Student', 'Essential Office apps for students and home users.', 249, 2499, 90, 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.6, 567, 100),

('550e8400-e29b-41d4-a716-446655440004', 'Microsoft 365 Family (6 Users)', 'Complete Office suite for up to 6 users with 1TB OneDrive storage each.', 499, 5299, 91, 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&q=80&w=1200', 'microsoft-365', 4.8, 723, 100);

-- Add sample product keys (in a real environment, these would be securely generated and stored)
INSERT INTO product_keys (product_id, key_value, is_used)
SELECT 
  p.id,
  'SAMPLE-KEY-' || gen_random_uuid(),
  false
FROM products p
CROSS JOIN generate_series(1, 10);